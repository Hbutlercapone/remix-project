require('./analysis/staticAnalysisCommon-test')

require('./analysis/staticAnalysisIntegration-test-0.4.24')
require('./analysis/staticAnalysisIssues-test-0.4.24')

require('./analysis/staticAnalysisIntegration-test-0.5.0')
require('./analysis/staticAnalysisIssues-test-0.5.0')
